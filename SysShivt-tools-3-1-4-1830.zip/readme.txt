You need SSVM 2.4.2 to 2.5.0 to install SysShivt tools.
How to install SysShivt tools:
1:  If you dont have SSVM, install it
    How to install SSVM:
    1:  Download a zip file from
        https://sysshivt-tools.webnode.cz/download-server
        or from the official github:
        https://github.com/Shivter14/SysShivt-tools
    2:  Extract the zip file
2:  Open SSVM [SSVM.cmd]
3:  Spam any key to enter the boot menu
3:  Press X and then press 2
4:  Drag this zip file to the SSVM window
    [it should automatically enter the full path of the
    zip file. If it doesn't, just type the full path of
    the zip file manually.]
5:  Press ENTER to continue to the installer
6:  Press Y
7:  Now the installer will ask you what version you want
    to install. Type "sysshivt-tools" and press ENTER.
8:  Select a SSVM virtual drive you want to install
    SysShivt tools to [Theese drives are just virtual
    drives stored in the SSVM directory]
9:  Press any key to install SysShivt tools
After installing sysshivt tools, just boot into the SSVM
virtual drive selected [If you didn't install SysShivt
tools to the C drive, spam any key to enter the boot
menu]