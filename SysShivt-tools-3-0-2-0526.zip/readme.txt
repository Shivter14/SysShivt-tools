Before you run the "autorun.cmd" file read this:
This version of SysShivt tools is based on SSVM
If you have SSVM, go to folder C, D, E, F, or G and copy everything from this zip to the folder
It doesn't really matter what folder you choose it will only change the slot
If you have fresh installation of SSVM with no system then choose the folder C

(sorry for my english im from Czechia (Evrope) )

- Shivter